import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { GoogleGenAI } from '@google/genai';

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json({ limit: '32kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));

const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;
const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

app.get('/health', (_req, res) => res.json({ ok: true, service: 'DilSe AI API' }));

app.post('/api/chat', async (req, res) => {
  try {
    if (!ai) return res.status(503).json({ error: 'Server is not configured. Add GEMINI_API_KEY to backend/.env.' });
    const { messages, personality = 'Romantic' } = req.body ?? {};
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 20) {
      return res.status(400).json({ error: 'Send between 1 and 20 chat messages.' });
    }
    const allowed = new Set(['Cute', 'Romantic', 'Caring', 'Funny']);
    const style = allowed.has(personality) ? personality : 'Romantic';
    const clean = messages.map(m => ({ role: m?.role === 'assistant' ? 'model' : 'user', text: String(m?.content ?? '').slice(0, 3000) }))
      .filter(m => m.text.trim()).slice(-16);
    if (!clean.length || clean[clean.length - 1].role !== 'user') return res.status(400).json({ error: 'Last message must be from the user.' });

    const system = `You are Aira, a fictional adult AI companion in the DilSe AI app. You are transparent that you are AI, never claim to be a real human or to have a real body, and never pressure users to spend money or isolate from real relationships. Speak naturally in the user's language (Hindi/Hinglish/English). Personality: ${style}. Be warm, affectionate and playful when the user welcomes it, but respect boundaries and say no to coercion. This app is for adults (18+); do not sexualize minors or engage in explicit sexual content. Do not provide professional medical, legal or financial advice. Keep most replies concise and conversational.`;
    const contents = clean.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
    const result = await ai.models.generateContent({ model, contents, config: { systemInstruction: system, temperature: 0.85, maxOutputTokens: 500 } });
    const reply = result.text?.trim();
    if (!reply) return res.status(502).json({ error: 'AI returned an empty response.' });
    res.json({ reply });
  } catch (err) {
    console.error('chat_error', err?.message || err);
    res.status(500).json({ error: 'AI request failed. Please try again.' });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, '0.0.0.0', () => console.log(`DilSe AI API listening on ${port}`));
