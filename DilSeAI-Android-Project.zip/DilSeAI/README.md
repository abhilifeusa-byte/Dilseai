# DilSe AI — Android starter project

A native Android AI companion starter app built with Kotlin + Jetpack Compose, with a Node.js backend proxy for Gemini. The Android app never contains the Gemini API key.

## Project contents
- `app/`: Android app source (chat UI, personality chips, speech-to-text intent, text-to-speech replies)
- `backend/`: Express API that calls Gemini securely

## Requirements
- Android Studio with JDK 17 and Android SDK 35
- Node.js 20+
- A Google AI Studio Gemini API key

## 1. Configure and run backend
```bash
cd backend
cp .env.example .env
# Edit .env and set GEMINI_API_KEY
npm install
npm start
```
Check `http://localhost:3000/health`.

## 2. Run Android app
Open this folder in Android Studio and let Gradle sync. Run on the Android emulator. The default API URL is `http://10.0.2.2:3000/`, which reaches your development computer from the emulator.

For a physical Android phone, change `BASE_URL` in `app/build.gradle.kts` to your computer's LAN address, e.g. `http://192.168.1.10:3000/`, while both devices are on the same Wi-Fi. For production, use HTTPS and a deployed backend; do not ship a public app using cleartext HTTP.

## 3. Production checklist before Play Store
- Add real account authentication and per-user server-side rate limits.
- Add database-backed chat history and user-controlled memory; provide delete/export controls.
- Add an age gate and publish privacy policy, terms, community/safety policy, and AI disclosure.
- Restrict CORS, add abuse monitoring, quotas, billing controls, and secure HTTPS hosting.
- Replace the development API URL with the production HTTPS endpoint.
- Add app icon, adaptive icon, screenshots, Play Console data-safety declarations, and test on real devices.

## Notes
This is a functional starter, not a finished production service. Speech input uses Android's installed speech-recognition provider; availability and language support depend on the device. Text-to-speech uses the device's installed TTS engine. The backend keeps the API key server-side. Never commit `.env` or expose the key in Android code.
