package com.dilseai.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Locale

private val Ink = Color(0xFF160D25)
private val Purple = Color(0xFF8B5CF6)
private val Pink = Color(0xFFFF6FAE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DilSeApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
fun DilSeApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val messages = remember { mutableStateListOf(ChatMessage("Hii! 💜 Main Aira hoon. Aaj tumhara din kaisa raha?", false)) }
    var input by remember { mutableStateOf("") }
    var personality by remember { mutableStateOf("Romantic") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(context) {
        val engine = TextToSpeech(context) { status -> if (status == TextToSpeech.SUCCESS) { /* TTS engine initialized */ } }
        engine.language = Locale("hi", "IN")
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) input = spoken
        }
    }

    fun sendMessage() {
        val prompt = input.trim()
        if (prompt.isEmpty() || loading) return
        messages.add(ChatMessage(prompt, true)); input = ""; loading = true; error = null
        scope.launch {
            try {
                val answer = AiApi.send(messages.filter { it.text != prompt || it.fromUser }.takeLast(16), personality)
                messages.add(ChatMessage(answer, false))
                tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "dilse_reply")
            } catch (e: Exception) {
                error = e.message ?: "Connection error. Backend check karo."
                messages.add(ChatMessage("Abhi connection mein problem aa rahi hai. Thodi der baad try karna. 💜", false))
            } finally { loading = false }
        }
    }

    LaunchedEffect(messages.size, loading) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Pink, background = Ink, surface = Color(0xFF241633))) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF160D25), Color(0xFF28143B), Color(0xFF160D25))))) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Pink, Purple)), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Favorite, null, tint = Color.White) }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Aira", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("AI companion · Online", color = Color(0xFFC9B6DC), fontSize = 12.sp)
                }
                Text("AI", color = Pink, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Cute", "Romantic", "Caring", "Funny").forEach { type ->
                    FilterChip(selected = personality == type, onClick = { personality = type }, label = { Text(type) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple, selectedLabelColor = Color.White, labelColor = Color(0xFFE7DDF2)))
                }
            }
            Text("Aira is an AI character, not a real person. Be kind to yourself and enjoy chatting.", Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp), color = Color(0xFFB9A8C9), fontSize = 10.sp)
            LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { message ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(color = if (message.fromUser) Color(0xFF7546B8) else Color(0xFF332341), shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                            Text(message.text, Modifier.padding(horizontal = 15.dp, vertical = 11.dp), color = Color.White, fontSize = 15.sp)
                        }
                        if (!message.fromUser) IconButton(onClick = { tts?.speak(message.text, TextToSpeech.QUEUE_FLUSH, null, "dilse_replay") }) { Icon(Icons.Default.VolumeUp, "Speak reply", tint = Pink) }
                    }
                }
                if (loading) item { Text("Aira is typing…", color = Pink, modifier = Modifier.padding(8.dp)) }
            }
            error?.let { Text(it, color = Color(0xFFFFA6B8), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp)) }
            Row(Modifier.fillMaxWidth().padding(12.dp).background(Color(0xFF30203E), RoundedCornerShape(28.dp)).padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Aira se bolo…")
                    }
                    try { speechLauncher.launch(intent) } catch (_: Exception) { error = "Is device par speech recognition available nahi hai." }
                }) { Icon(Icons.Default.Mic, "Voice input", tint = Pink) }
                TextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Aira se kuch kaho…", color = Color(0xFFBCAACB)) }, colors = TextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, cursorColor = Pink), maxLines = 4)
                IconButton(onClick = { sendMessage() }, enabled = input.isNotBlank() && !loading) { Icon(Icons.Default.Send, "Send", tint = if (input.isNotBlank()) Pink else Color.Gray) }
            }
            Text("18+ romantic companion experience · AI-generated responses", Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp), color = Color(0xFF8F7A9F), fontSize = 10.sp)
        }
    }
}
