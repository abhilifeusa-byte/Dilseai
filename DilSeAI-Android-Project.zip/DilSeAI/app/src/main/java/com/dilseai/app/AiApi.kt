package com.dilseai.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object AiApi {
    private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    suspend fun send(messages: List<ChatMessage>, personality: String): String = withContext(Dispatchers.IO) {
        val history = JSONArray()
        messages.forEach { history.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text)) }
        val body = JSONObject().put("personality", personality).put("messages", history).toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url(BuildConfig.BASE_URL + "api/chat").post(body).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("Server error ${response.code}: $raw")
            JSONObject(raw).optString("reply").ifBlank { "Mujhe abhi jawab nahi mil paaya. Phir se try karoge?" }
        }
    }
}
